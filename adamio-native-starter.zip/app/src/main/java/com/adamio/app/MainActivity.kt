package com.adamio.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Purple = Color(0xFF7C4DFF)
private val Violet = Color(0xFF9C27B0)
private val Ink = Color(0xFF25213A)
private val Soft = Color(0xFFF4F0FF)
private val Teal = Color(0xFF2BB5A0)
private val Governorates = listOf("تونس", "أريانة", "بن عروس", "منوبة", "نابل", "زغوان", "بنزرت", "باجة", "جندوبة", "الكاف", "سليانة", "القيروان", "القصرين", "سيدي بوزيد", "سوسة", "المنستير", "المهدية", "صفاقس", "قابس", "مدنين", "تطاوين", "قفصة", "توزر", "قبلي")
private val PathNames = listOf("التحيات والتعارف", "الأرقام", "الألوان", "العائلة", "الوقت والتاريخ", "المنزل", "المدرسة", "الطعام", "الملابس", "الجسم", "الصحة", "الطقس", "المدينة", "المواصلات", "التسوق", "العمل", "الهوايات", "الرياضة", "السفر", "المطعم", "المشاعر", "الصفات", "الأفعال اليومية", "الأسئلة", "النفي", "الماضي", "المستقبل", "الوصف", "المقارنة", "الأصدقاء", "الثقافة", "الطبيعة", "الحيوانات", "النباتات", "المهن", "التكنولوجيا", "الإنترنت", "السينما", "الموسيقى", "الأدب", "التاريخ", "الجغرافيا", "الاقتصاد", "التجارة", "الإدارة", "المجتمع", "القانون", "السياسة", "البيئة", "العلوم", "الفلسفة", "الإعلام", "الصحافة", "الحوار", "السرد", "الحجج", "النقاش", "التعبير الكتابي", "الرسائل", "المقالات", "الملخص", "التحليل", "الاستنتاج", "النقد", "الأسلوب", "الإتقان")

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { AdamioApp() } }
}

@Composable
private fun AdamioApp() {
    var page by remember { mutableIntStateOf(0) }
    MaterialTheme(colorScheme = lightColorScheme(primary = Purple, secondary = Teal, background = Soft, surface = Color.White)) {
        Scaffold(containerColor = Soft, bottomBar = {
            NavigationBar(containerColor = Color.White, tonalElevation = 5.dp) {
                val labels = listOf("الرئيسية", "خططي", "اللغة", "صفحتي")
                val icons = listOf(Icons.Default.Home, Icons.Default.GridView, Icons.Default.MenuBook, Icons.Default.Person)
                labels.forEachIndexed { index, label -> NavigationBarItem(selected = page == index, onClick = { page = index }, icon = { Icon(icons[index], contentDescription = label) }, label = { Text(label, fontSize = 12.sp) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Purple, selectedTextColor = Purple, indicatorColor = Soft)) }
            }
        }) { padding ->
            Box(Modifier.fillMaxSize().padding(padding).background(Brush.verticalGradient(listOf(Soft, Color.White)))) {
                when (page) { 0 -> HomeScreen(); 1 -> PlansScreen(); 2 -> LanguageScreen(); else -> ProfileScreen() }
            }
        }
    }
}

@Composable
private fun GradientCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Brush.linearGradient(listOf(Purple, Violet))).padding(20.dp), content = content)
}

@Composable
private fun ScreenTitle(title: String, subtitle: String) {
    Column(Modifier.fillMaxWidth().padding(bottom = 20.dp), horizontalAlignment = Alignment.End) {
        Text(title, fontSize = 27.sp, color = Ink, fontWeight = FontWeight.Bold)
        Text(subtitle, color = Color(0xFF7D7890), fontSize = 14.sp)
    }
}

@Composable
private fun HomeScreen() {
    var level by remember { mutableStateOf("A1") }
    var showLevels by remember { mutableStateOf(false) }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            ScreenTitle("مرحبًا بك في adamio", "رحلتك لتعلم الفرنسية تبدأ هنا")
            GradientCard {
                Text("مسار تعلم الفرنسية", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 22.sp)
                Spacer(Modifier.height(8.dp))
                Text("اختر المستوى وتقدم عبر المسارات", color = Color.White.copy(alpha = .85f))
                Spacer(Modifier.height(16.dp))
                Button(onClick = { showLevels = true }, colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Purple)) { Text("المستوى $level  •  20 فصلًا") }
            }
            Spacer(Modifier.height(18.dp))
            Text("المسارات • 66", color = Ink, fontSize = 21.sp, fontWeight = FontWeight.Bold)
        }
        itemsIndexed(PathNames) { index, name ->
            val unlocked = index < 5
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Color.White).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(54.dp).clip(CircleShape).background(if (unlocked) Brush.linearGradient(listOf(Purple, Teal)) else Brush.linearGradient(listOf(Color(0xFFD9D8E2), Color(0xFFE8E8EF)))), contentAlignment = Alignment.Center) {
                    Icon(if (unlocked) Icons.Default.AutoStories else Icons.Default.Lock, contentDescription = null, tint = Color.White)
                }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.End) {
                    Text(name, fontWeight = FontWeight.Bold, color = Ink)
                    Text(if (unlocked) "متاح • تصميم أولي" else "مغلق", color = Color.Gray, fontSize = 12.sp)
                }
                Spacer(Modifier.width(8.dp))
                Text("${index + 1}", color = Purple, fontWeight = FontWeight.Bold)
            }
        }
    }
    if (showLevels) AlertDialog(onDismissRequest = { showLevels = false }, title = { Text("اختر المستوى") }, text = { Column { listOf("A1", "A2", "B1", "B2", "C1").forEach { item -> TextButton(onClick = { level = item; showLevels = false }, modifier = Modifier.fillMaxWidth()) { Text("$item — 20 فصلًا") } } } }, confirmButton = { TextButton(onClick = { showLevels = false }) { Text("إغلاق") } })
}

@Composable
private fun PlansScreen() {
    val names = listOf("مستودع الدروس", "مستودع الكلمات الإثرائية", "مستودع القصص والاقتباسات", "مستودع الحجج والأمثلة")
    var selected by remember { mutableStateOf<String?>(null) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp)) {
        ScreenTitle("خططي", "المستودعات والخطة المخصصة")
        names.forEachIndexed { i, name ->
            Card(Modifier.fillMaxWidth().padding(bottom = 12.dp), shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(44.dp).clip(RoundedCornerShape(14.dp)).background(if (i % 2 == 0) Soft else Color(0xFFE5F8F3)), contentAlignment = Alignment.Center) { Icon(Icons.Default.Folder, null, tint = if (i % 2 == 0) Purple else Teal) }
                    Spacer(Modifier.width(12.dp))
                    Text(name, Modifier.weight(1f), color = Ink, fontWeight = FontWeight.SemiBold)
                    TextButton(onClick = { selected = name }) { Text("الملفات") }
                }
            }
        }
        Text("هذه واجهة تأسيسية؛ لم تُنشأ مستودعات أو ملفات وهمية.", color = Color.Gray, fontSize = 13.sp)
    }
    if (selected != null) AlertDialog(onDismissRequest = { selected = null }, title = { Text(selected!!) }, text = { Text("صفحة إدارة الملفات ستُبنى في المرحلة التالية.") }, confirmButton = { TextButton(onClick = { selected = null }) { Text("إغلاق") } })
}

@Composable
private fun LanguageScreen() {
    var selected by remember { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        ScreenTitle("اللغة", "القواعد والمفردات من ملفاتك")
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Color.White).padding(5.dp)) {
            listOf("Grammaire", "Vocabulaire").forEachIndexed { index, name ->
                Box(Modifier.weight(1f).clip(RoundedCornerShape(14.dp)).background(if (selected == index) Purple else Color.Transparent).clickable { selected = index }.padding(14.dp), contentAlignment = Alignment.Center) { Text(name, color = if (selected == index) Color.White else Ink, fontWeight = FontWeight.SemiBold) }
            }
        }
        Spacer(Modifier.height(20.dp))
        Text("لم تُرفع ملفات بعد. لن نُنشئ دروسًا غير موجودة في ملفاتك.", color = Color.Gray, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
    }
}

@Composable
private fun ProfileScreen() {
    var name by remember { mutableStateOf("مستخدم adamio") }
    var governorate by remember { mutableStateOf("اختر الولاية") }
    var institute by remember { mutableStateOf("") }
    var edit by remember { mutableStateOf(false) }
    var settings by remember { mutableStateOf(false) }
    var tab by remember { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { settings = true }) { Icon(Icons.Default.Settings, "الإعدادات", tint = Purple) }
            Text("صفحتي", color = Ink, fontSize = 27.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(14.dp))
        GradientCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(72.dp).clip(CircleShape).background(Color.White.copy(alpha = .25f)), contentAlignment = Alignment.Center) { Icon(Icons.Default.Person, null, tint = Color.White, modifier = Modifier.size(42.dp)) }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.End) {
                    Text(name, color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                    Text(governorate, color = Color.White.copy(alpha = .9f), fontSize = 13.sp)
                    if (institute.isNotBlank()) Text(institute, color = Color.White.copy(alpha = .8f), fontSize = 13.sp)
                }
            }
            Spacer(Modifier.height(16.dp))
            Button(onClick = { edit = true }, colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Purple), modifier = Modifier.align(Alignment.End)) { Icon(Icons.Default.Edit, null, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(8.dp)); Text("تعديل الملف الشخصي") }
        }
        Spacer(Modifier.height(16.dp))
        Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Color.White), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(18.dp), horizontalAlignment = Alignment.End) {
                Text("أصدقاء عبر الدعوة", color = Ink, fontWeight = FontWeight.Bold)
                Text("غير متاح حتى ربط الحسابات", color = Color.Gray, fontSize = 13.sp)
                HorizontalDivider(Modifier.padding(vertical = 12.dp), color = Soft)
                Text("رابط الدعوة سيُفعّل بعد إعداد الحسابات والتحقق من التسجيل.", color = Color.Gray, fontSize = 13.sp)
            }
        }
        Spacer(Modifier.height(22.dp))
        val tabs = listOf("التقدم", "اللغة", "تحليل التعلم")
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Color.White).padding(5.dp)) {
            tabs.forEachIndexed { index, label ->
                Box(Modifier.weight(1f).clip(RoundedCornerShape(14.dp)).background(if (tab == index) Brush.linearGradient(listOf(Purple, Violet)) else Brush.linearGradient(listOf(Color.Transparent, Color.Transparent))).clickable { tab = index }.padding(vertical = 12.dp), contentAlignment = Alignment.Center) {
                    Text(label, color = if (tab == index) Color.White else Color.Gray, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        // تبويبات الملف الشخصي فارغة عمدًا، حسب آخر تعليمات المستخدم.
    }
    if (edit) {
        var draftName by remember { mutableStateOf(name) }
        var draftInstitute by remember { mutableStateOf(institute) }
        var expanded by remember { mutableStateOf(false) }
        var draftGovernorate by remember { mutableStateOf(governorate) }
        AlertDialog(onDismissRequest = { edit = false }, title = { Text("تعديل الملف الشخصي") }, text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(draftName, { draftName = it }, label = { Text("الاسم") }, singleLine = true)
                Box { OutlinedButton(onClick = { expanded = true }) { Text(draftGovernorate) }; DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }, modifier = Modifier.heightIn(max = 300.dp)) { Governorates.forEach { g -> DropdownMenuItem(text = { Text(g) }, onClick = { draftGovernorate = g; expanded = false }) } } }
                OutlinedTextField(draftInstitute, { draftInstitute = it }, label = { Text("المعهد") }, singleLine = true)
            }
        }, confirmButton = { TextButton(onClick = { name = draftName.ifBlank { "مستخدم adamio" }; governorate = draftGovernorate; institute = draftInstitute; edit = false }) { Text("حفظ") } }, dismissButton = { TextButton(onClick = { edit = false }) { Text("إلغاء") } })
    }
    if (settings) AlertDialog(onDismissRequest = { settings = false }, title = { Text("الإعدادات") }, text = { Text("إعدادات اللغة والسمات ستُضاف في المرحلة القادمة.") }, confirmButton = { TextButton(onClick = { settings = false }) { Text("إغلاق") } })
}
