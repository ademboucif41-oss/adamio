# adamio — Android Native (Foundation v0.1)

A new independent Kotlin + Jetpack Compose Android project. Does not modify the existing Franco-Studio repository.

## Open and build
1. Open this folder in Android Studio (JDK 17, Android SDK 35).
2. Sync Gradle (requires internet for dependency downloads).
3. Run on Android device or Build > Build APK(s).

## Implemented
- Material 3 purple gradient interface; four bottom tabs.
- Home: 66 **provisional placeholder** French path labels, first five visually unlocked; level selector A1-C1. No lesson unlocking logic yet.
- Plans: four **provisional placeholder** repository labels; file management not yet connected.
- Language: grammar/vocabulary tabs, no fabricated content.
- Profile: editable name, governorate (24), institute (in-memory only), invitation placeholder (no fake numbers), three deliberately empty subpages.

## Not yet implemented
- Persistence, authentication, invitations, referral discounts, real learning data, charts, French translations, actual lesson tests, photo picker, horizontal swipe between profile tabs, Haze, and actual APK validation.
- All names/content must be reconciled with the existing specification before production.

No APK is included: this environment has not run an Android Gradle build.
